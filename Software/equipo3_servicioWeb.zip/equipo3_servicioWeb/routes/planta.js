var express = require('express'); // Declarando dependencia del modulo express
var router = express.Router(); // Variable para redirigir las peticiones que reciba externamente

var controller = require('../controllers/planta.controller'); // Variable que contiene la ruta del planta.controller.js
// localhost:8030/planta

router.get('/persona',controller.persona_list);
router.post('/persona',controller.insert_persona);
router.get('/planta',controller.planta_list);
router.post('/planta',controller.insert_planta);
router.get('/lectura/:id',controller.lectura_list);
router.post('/lectura',controller.insert_lectura);

module.exports = router; // Objeto que quiero exportar o hacer publico fuera de este archivo
