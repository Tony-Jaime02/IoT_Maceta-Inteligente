const { response, request } = require('express');

var mysql = require('mysql'); // Declarando dependencia del modulo mysql

var config = require('../helpers/config'); // Variable que contiene la ruta del config.js

var conexion = mysql.createConnection(config); // Crear la conexion con los datos almacenados en config

module.exports.persona_list = (reques,response) => {

    var sql = 'SELECT * FROM persona';
    conexion.query(sql,(error,results,fields) => {
        if(error){
            response.send(error)
        }
        else{
            response.json(results);
        }
    });
}

module.exports.planta_list = (reques,response) => {

    var sql = 'SELECT * FROM planta';
    conexion.query(sql,(error,results,fields) => {
        if(error){
            response.send(error)
        }
        else{
            response.json(results);
        }
    });
}

module.exports.lectura_list = (reques,response) => {
    var id = reques.params.id;
    //var sql = `SELECT * FROM lectura WHERE planta_id_planta = ${id} ORDER BY fecha DESC,hora DESC LIMIT 5`;
    var sql = 'SELECT * FROM lectura WHERE planta_id_planta = ? ORDER BY fecha DESC,hora DESC LIMIT 5';
    conexion.query(sql,[id],(error,results,fields) => {
        if(error){
            response.send(error)
        }
        else{
            response.json(results);
        }
    });
}

module.exports.insert_persona = (request, response) => {

    var persona = request.body; // contiene los datos de la persona en formato json y se lo envía a la planta
    var sql = 'INSERT INTO persona SET ?'; 
    conexion.query(sql,[persona], 
        (error, results, fields) =>{
        if (error){
            response.send(error);
        }else{
            response.json(results);
        }
    });
}

module.exports.insert_planta = (request, response) => {

    var planta = request.body; // contiene los datos de la persona en formato json y se lo envía a la planta
    var sql = 'INSERT INTO planta SET ?'; 
    conexion.query(sql,[planta], 
        (error, results, fields) =>{
        if (error){
            response.send(error);
        }else{
            response.json(results);
        }
    });
}

module.exports.insert_lectura = (request, response) => {

    var planta = request.body; // contiene los datos de la planta en formato json y se lo envía a la lectura
    console.log(planta);
    console.log("---")
    if(planta.id_lectura != null && planta.sens_luz != null && planta.sens_humA != null && planta.sens_tempA != null && planta.sens_humT != null && planta.planta_id_planta != null){
        var sql = 'INSERT INTO lectura VALUES(?,?,?,?,?,CURRENT_TIME,CURRENT_DATE,?)'; 
        conexion.query(sql,[planta.id_lectura, planta.sens_luz,planta.sens_humA,planta.sens_tempA,planta.sens_humT, planta.planta_id_planta], 
            (error, results, fields) =>{
            if (error){
                response.send(error);
            }else{
                response.json(results);
            }
        });
    }else{
        response.json({"error": "Los datos recibidos no tienen el formato necesario"});
    }
}