// Declarando dependencias de diferentes modulos
var express = require('express');
var bodyParser = require('body-parser');
var path = require('path');
var cors = require('cors');

var index = require('./routes/index'); // Variable que contiene la ruta del index.js
var planta = require('./routes/planta'); // Variable que contiene la ruta del planta.js

var port = 8030; // Declarando port en el 8060
var app = express(); // Metodos necesarios para poder crear una aplicacion web

app.use(cors()); // Inicializamos el cors()
app.use(bodyParser.json()); // Lo que recibamos del cliente o de la base de datos se convertira en formato JSON
app.use(bodyParser.urlencoded({extended: false})); // La informacion que recibamos desde el cliente o base de datos no estara codificada
app.use(express.static(__dirname + '/frontend')); // Enlazando a nuestro frontend de la pagina web

app.use('/', index); // Acceder al archivo index.js desde la raiz del sitio
app.use('/api', planta); // Acceder al archivo planta.js desde la ruta /api
 
// Inicializar el servidor para poner en linea nuestra API
app.listen(port, () => {
    console.log('El servidor inicio en el puerto ' + port);
});

app.set('json replacer', function (key, value) {
    if (this[key] instanceof Date) {
      // Your own custom date serialization
      value = this[key].toLocaleString().split(' ')[0];
    }
  
    return value;
  });