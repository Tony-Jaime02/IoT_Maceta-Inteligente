// Configuracion de la base de datos en MySQL
var config = {
    host:'iot.omarquintero.com',
    user:'equipo3',
    password:'HiXxEHZq',
    database:'equipo3' 
}

module.exports = config; // Objeto que quiero exportar o hacer publico fuera de este archivo
